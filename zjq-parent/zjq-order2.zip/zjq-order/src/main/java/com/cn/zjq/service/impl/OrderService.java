package com.cn.zjq.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import com.cn.zjq.mapper.read.OrderReadMapper;
import com.cn.zjq.mapper.write.OrderWriteMapper;
import com.zjq.common.domain.order.Order;
import com.zjq.common.exception.BusinessException;
import com.zjq.common.service.order.IOrderService;

@Service
public class OrderService implements IOrderService{
	
	@Autowired
	private OrderReadMapper orderReadMapper;
	
	@Autowired
	private OrderWriteMapper orderWriteMapper;

	@Override
	public Object findById(Integer id) {
		return orderReadMapper.selectByPrimaryKey(id);
	}

	@Override
	public void update(Object obj) {
		Order order = (Order) obj;
		orderWriteMapper.updateByPrimaryKey(order);
	}

	@Override
	@Transactional
	public void save(Order order) {
		try {
			orderWriteMapper.insert(order);
			throw new RuntimeException("test");
		} catch (RuntimeException e) {
			System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
			e.printStackTrace();
		}
	}

}
