package com.cn.zjq.web;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cn.zjq.service.IQuestionService;

@RequestMapping(value="/question")
@RestController
public class UserController {
	
	@Autowired
	private IQuestionService questionService;
	
	@RequestMapping(value="/all")  
    public Map<String, Object> all(){  
          
        return questionService.initFormData();  
    }
}
