package com.cn.zjq.mapper.read;

import com.cn.zjq.entity.Question;

public interface QuestionReadMapper {

  Question selectByPrimaryKey(Integer id);

  int checkCodeUnique(Question question);

}
